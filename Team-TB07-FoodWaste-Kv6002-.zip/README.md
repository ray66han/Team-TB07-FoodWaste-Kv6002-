# Team-TB07-FoodWaste-Kv6002-

This repository will be used by TB07 team (KV6002) regarding to build a Food Waste system.

Pre requesits:

# Install Node.js

#download and install Node.js

choco install nodejs-lts --version="20.18.0"

#verifies the right Node.js version is in the environment

node -v # should print `20`

#verifies the right npm version is in the environment

npm -v # should print `10.8.2`

# Go to project directory and run react app

#cd into cloned project

cd Team-TB07-FoodWaste-Kv6002-\react-app

#install react using vite

npm install

#run the project

npm run dev # you should be able to view the web app link locally
