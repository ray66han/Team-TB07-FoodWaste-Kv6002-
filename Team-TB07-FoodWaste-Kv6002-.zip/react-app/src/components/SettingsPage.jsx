import React from 'react';

function SettingsPage() {
  return (
    <div>
      Hello, World! Settings page
    </div>
  );
}

export default SettingsPage;