import React from 'react';

function LoginPage() {
  return (
    <div>
      Hello, World! LoginPage
    </div>
  );
}

export default LoginPage;