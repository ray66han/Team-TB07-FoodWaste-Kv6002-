import React from 'react';

function Notifications() {
  return (
    <div>
      Hello, World! notifications page
    </div>
  );
}

export default Notifications;